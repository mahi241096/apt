﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace connect
{
    public partial class Form1 : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter sda;
        SqlDataReader rdr;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Admin;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            con.Open();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == string.Empty)
            {
                errorProvider1.SetError(textBox1, "can't blank");
                textBox1.Focus();
                MessageBox.Show("please fill it");
            }
            else
            {
                HelpProvider hlp = new HelpProvider();
                hlp.SetShowHelp(textBox2,true);
                hlp.SetHelpString(textBox2,"Enter a valid text");

                hlp.HelpNamespace="my.chm";
                hlp.SetHelpNavigator(textBox2,HelpNavigator.TableOfContents);



                String quy = "insert into login(id,name,pass)values('" + textBox3.Text + "','" + textBox1.Text + "','" + textBox2.Text + "')";
                cmd = new SqlCommand(quy, con);
                int ans = cmd.ExecuteNonQuery();
                if (ans > 0)
                {
                    MessageBox.Show("inserted successfully");
                    sda = new SqlDataAdapter("select * from login", con);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            String quy = "update login set  name = '"+textBox1.Text+"', pass='"+textBox2.Text+ "' where id='" + textBox3.Text + "' ";
            cmd = new SqlCommand(quy, con);
            int ans = cmd.ExecuteNonQuery();
            if(ans>0)
            {
                MessageBox.Show("Updated successfully");
                sda = new SqlDataAdapter("select * from login", con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView1.DataSource = dt;

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            String quy = "delete from login where id='" + textBox3.Text + "'";
            cmd = new SqlCommand(quy, con);
            int ans = cmd.ExecuteNonQuery();
            if (ans > 0)
            {
                MessageBox.Show("Deleted successfully");
                sda = new SqlDataAdapter("select * from login", con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox3.Text = "";
            textBox1.Text = "";
            textBox2.Text = "";
        }

        private void select_Click(object sender, EventArgs e)
        {
            sda = new SqlDataAdapter("select * from login",con);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            DataView dv = new DataView();
            dataGridView2.DataSource = ds.Tables[0].DefaultView;
          
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
    }
}
